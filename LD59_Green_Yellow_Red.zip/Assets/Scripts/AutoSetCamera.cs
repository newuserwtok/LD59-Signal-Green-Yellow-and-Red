using Unity.Cinemachine;
using UnityEngine;
using UnityEngine.SceneManagement;

public class AutoSetCamera : MonoBehaviour
{
    private CinemachineCamera cm;

    void Awake()
    {
        cm = GetComponent<CinemachineCamera>();
        GameObject player = GameObject.FindWithTag("Player");
        if (player != null) 
        {
            cm.Follow = player.transform;
        }
    }
}
