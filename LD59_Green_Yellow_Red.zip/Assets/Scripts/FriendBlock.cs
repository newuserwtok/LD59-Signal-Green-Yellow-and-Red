using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static SignalManager;

public class FriendBlock : MonoBehaviour
{
    [Header("回放速度")]
    public float replaySpeed = 1f;

    
    private Vector2 startPos;
    private List<Vector2> moveRecord = new List<Vector2>();
    private Coroutine replayCoroutine;

    private bool isBlue;
    public bool isReplaying = false;

    private Collider2D col;
    private Rigidbody2D rb;

    private void Awake()
    {
        col = GetComponent<Collider2D>();
        rb = GetComponent<Rigidbody2D>();

        col.enabled = true;
        rb.bodyType = RigidbodyType2D.Kinematic;

        startPos = transform.position;
    }

    private void OnEnable()
    {
        SignalManager.OnSignalChanged += OnSignalStateChange;
    }
    private void OnDisable()
    {
        SignalManager.OnSignalChanged -= OnSignalStateChange;
    }

    private void OnSignalStateChange(SignalState state)
    {
        if (state == SignalState.Blue)
        {
            isBlue = true;
            moveRecord.Clear();

            if (replayCoroutine != null) StopCoroutine(replayCoroutine);

            rb.bodyType = RigidbodyType2D.Dynamic;
        }
        else
        {
            isBlue = false;
            if (isReplaying)
            {
                return;
            }
            else if(!isReplaying && moveRecord.Count == 0)
            {
                rb.bodyType = RigidbodyType2D.Kinematic;
                rb.linearVelocity = Vector2.zero;
            }
            else
            {
                replayCoroutine = StartCoroutine(ReplayMove());
            }
        }
    }
    private void Update()
    {
        if (isBlue)
        {
            moveRecord.Add(transform.position);
        }
    }

    IEnumerator ReplayMove()
    {
        isReplaying = true;
        for (int i = 0; i < moveRecord.Count; i++)
        {
            transform.position = Vector2.Lerp(transform.position, moveRecord[i], replaySpeed);
            yield return null;
        }

        startPos = transform.position;
        moveRecord.Clear();
        isReplaying = false;
        replayCoroutine = null;
    }
}