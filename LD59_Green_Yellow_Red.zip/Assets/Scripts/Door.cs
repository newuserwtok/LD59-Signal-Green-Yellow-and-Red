using UnityEngine;
using UnityEngine.SceneManagement;

public class Door : MonoBehaviour
{
    [Header("下一个场景名称")]
    public string targetScene;
    private void Start()
    {
        transform.tag = "Door";
    }
    public void ChangeScene()
    {
        FindAnyObjectByType<UIManager>().WinScene();
        SceneManager.LoadScene(targetScene);
    }
}
