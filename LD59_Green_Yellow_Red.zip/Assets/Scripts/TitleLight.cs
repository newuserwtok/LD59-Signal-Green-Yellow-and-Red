using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class TitleLight : MonoBehaviour
{
    public enum SignalState
    {
        Green,
        Yellow,
        Red,
    }

    public Camera cam;

    public SignalState currentState;

    public float greenTime = 1.8f;
    public float yellowTime = 1.8f;
    public float redTime = 1.8f;

    private float timer;

    void Start()
    {
        SwitchState(SignalState.Green);
    }

    void Update()
    {
        timer -= Time.deltaTime;

        if (timer <= 0)
        {
            NextState();
        }
    }

    void NextState()
    {
        if (currentState == SignalState.Green)
            SwitchState(SignalState.Yellow);
        else if (currentState == SignalState.Yellow)
            SwitchState(SignalState.Red);
        else
            SwitchState(SignalState.Green);
    }

    void SwitchState(SignalState newState)
    {
        currentState = newState;

        switch (newState)
        {
            case SignalState.Green:
                cam.backgroundColor = Color.green;
                timer = greenTime;
                break;
            case SignalState.Yellow:
                cam.backgroundColor = Color.yellow;
                timer = yellowTime;
                break;
            case SignalState.Red:
                cam.backgroundColor = Color.red;
                timer = redTime;
                break;
        }
    }
}
