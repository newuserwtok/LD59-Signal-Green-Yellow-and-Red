using System.Collections;
using UnityEngine;
using static SignalManager;

public class TimeStop : MonoBehaviour
{
    public float duration = 6f;
    private Coroutine blueAppearRoutine;

    private SignalState currentState;
    void OnEnable()
    {
        SignalManager.OnSignalChanged += OnSignalChanged;
    }

    void OnDisable()
    {
        SignalManager.OnSignalChanged -= OnSignalChanged;
    }
    void OnSignalChanged(SignalState state)
    {
        currentState = state;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            if (currentState != SignalState.Blue && !IsAnyBlockReplaying())
            {
                Debug.Log("Blue!");
                FindFirstObjectByType<SignalManager>().TurnBlue();
                blueAppearRoutine = StartCoroutine(BlueAppear());
            }
            else return;
        }
    }
    IEnumerator BlueAppear()
    {
        GetComponent<SpriteRenderer>().enabled = false;
        GetComponent<Collider2D>().enabled = false;
        yield return new WaitForSeconds(18f);
        GetComponent<SpriteRenderer>().enabled = true;
        GetComponent<Collider2D>().enabled = true;
    }
    private bool IsAnyBlockReplaying()
    {
        FriendBlock[] allBlocks = FindObjectsByType<FriendBlock>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);

        foreach (FriendBlock item in allBlocks)
        {
            if (item.isReplaying)
                return true;
        }
        return false;
    }
}
