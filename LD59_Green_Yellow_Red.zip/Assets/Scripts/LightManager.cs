using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using static SignalManager;

public class BackgroundController : MonoBehaviour
{
    public Camera cam;
    private SignalState currentState;
    
    private Coroutine yellowRoutine;

    void OnEnable()
    {
        SignalManager.OnSignalChanged += OnSignalChanged;
    }

    void OnDisable()
    {
        SignalManager.OnSignalChanged -= OnSignalChanged;
    }

    void OnSignalChanged(SignalState state)
    {
        currentState = state;

        //每次切换信号先停止闪烁协程
        if (yellowRoutine != null)
        {
            StopCoroutine(yellowRoutine);
        }

        switch (state)
        {
            case SignalState.Green:
                cam.backgroundColor = new Color(0.25f, 0.8f, 0.25f);
                break;
            case SignalState.Yellow:
                yellowRoutine = StartCoroutine(FlashYellow());
                break;
            case SignalState.Red:
                cam.backgroundColor = new Color(0.8f, 0.25f, 0.25f);
                break;
            case SignalState.Blue:
                cam.backgroundColor = new Color(0.2f, 0.2f, 0.85f);
                break;
        }
    }

    IEnumerator FlashYellow()
    {
        while (currentState == SignalState.Yellow)
        {
            cam.backgroundColor = new Color(0.8f, 0.8f, 0.25f);
            yield return new WaitForSeconds(0.2f);
            cam.backgroundColor = Color.gray;
            yield return new WaitForSeconds(0.2f);
        }
    }
}