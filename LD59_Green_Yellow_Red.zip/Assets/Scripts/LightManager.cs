using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using static SignalManager;

public class BackgroundController : MonoBehaviour
{
    public Camera cam;
    private SignalState currentState;
    
    private Coroutine yellowRoutine;

    void OnEnable()
    {
        SignalManager.OnSignalChanged += OnSignalChanged;
    }

    void OnDisable()
    {
        SignalManager.OnSignalChanged -= OnSignalChanged;
    }

    void OnSignalChanged(SignalState state)
    {
        currentState = state;

        //每次切换信号先停止闪烁协程
        if (yellowRoutine != null)
        {
            StopCoroutine(yellowRoutine);
        }

        switch (state)
        {
            case SignalState.Green:
                cam.backgroundColor = Color.green;
                break;
            case SignalState.Yellow:
                yellowRoutine = StartCoroutine(FlashYellow());
                break;
            case SignalState.Red:
                cam.backgroundColor = Color.red;
                break;
            case SignalState.Blue:
                cam.backgroundColor = Color.blue;
                break;
        }
    }

    IEnumerator FlashYellow()
    {
        while (currentState == SignalState.Yellow)
        {
            cam.backgroundColor = Color.yellow;
            yield return new WaitForSeconds(0.2f);
            cam.backgroundColor = Color.gray;
            yield return new WaitForSeconds(0.2f);
        }
    }
}