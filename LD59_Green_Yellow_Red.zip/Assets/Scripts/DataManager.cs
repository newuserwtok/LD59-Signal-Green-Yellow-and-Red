using UnityEngine;

public class DataManager : MonoBehaviour
{
    public static DataManager instance;

    public float totalPlayTime = 0f;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void AddTime(float time)
    {
        instance.totalPlayTime += time;
    }
    public void ResetTime()
    {
        instance .totalPlayTime = 0f;
    }
}