using UnityEngine;
using UnityEngine.SceneManagement;

public class TitleCtrl : MonoBehaviour
{
    public void StartGame()
    {
        SceneManager.LoadScene("SampleScene");
    }

    public GameObject GuidePage;
    public void OpenGuide()
    {
        GuidePage.SetActive(true);
    }
    public void CloseGuide()
    {
        GuidePage.SetActive(false);
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
