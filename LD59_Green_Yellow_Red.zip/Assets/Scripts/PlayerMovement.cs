using UnityEngine;
using static SignalManager;

public class PlayerMovement : MonoBehaviour
{
    private Rigidbody2D playerRB;
    private BoxCollider2D playerColl;

    [Header("移动参数")]
    public float speed = 8f;
    float xVelocity;

    [Header("跳跃参数")]
    public float jumpForce = 15f;

    [Header("状态参数")]
    public bool isOnGround;
    public bool isJumping;
    public bool isOnIce;

    //按键检测
    bool isJumpingPressed;

    [Header("环境检测")]
    //两脚位置
    float footOffset;
    //两脚检测距离
    public float footDistance = 0.2f;

    public LayerMask groundLayer;

    void Start()
    {
        playerRB = GetComponent<Rigidbody2D>();

        playerColl = GetComponent<BoxCollider2D>();
        footOffset = playerColl.size.x / 2f;

    }

    void Update()
    {
        //按键检测
        if (Input.GetButtonDown("Jump"))
        {
            isJumpingPressed = true;
        }
    }

    private void FixedUpdate()
    {
        PhysicsCheck();
        GroundMovement();
        MidAirMovement();
    }
    
    void PhysicsCheck()
    {
        //左右脚向下射线
        RaycastHit2D leftCheck = Raycast(new Vector2(-footOffset, 0f), Vector2.down, footDistance, groundLayer);
        RaycastHit2D rightCheck = Raycast(new Vector2(footOffset, 0f), Vector2.down, footDistance, groundLayer);
        isOnGround = leftCheck || rightCheck;
        if (isOnGround)
        {
            isJumping = false;
        }
        isOnIce = leftCheck.collider != null && leftCheck.collider.CompareTag("Ice")
        || rightCheck.collider != null && rightCheck.collider.CompareTag("Ice");
    }
    void GroundMovement()
    {
        xVelocity = Input.GetAxis("Horizontal");

        //人物翻转
        FlipDirection();

        if (playerRB.bodyType == RigidbodyType2D.Dynamic)
        {
            if (Mathf.Abs(xVelocity) > 0.01f)
            {
                playerRB.linearVelocity = new Vector2(xVelocity * speed, playerRB.linearVelocity.y);
            }
            else
            {
                float decel = isOnIce ? 0.9995f : 0f;
                playerRB.linearVelocity = new Vector2(playerRB.linearVelocity.x * decel, playerRB.linearVelocity.y);
            }
        }
    }
    void MidAirMovement()
    {

        if (isJumpingPressed && isOnGround && !isJumping)
        {

            isOnGround = false;
            isJumping = true;

            playerRB.AddForce(new Vector2(0f, jumpForce), ForceMode2D.Impulse);
        }
        else
        {

        }
        //及时重置跳跃状态
        isJumpingPressed = false;

        
        if (playerRB.linearVelocity.y > 0 && !Input.GetButton("Jump"))
        {
            playerRB.linearVelocity = new Vector2(playerRB.linearVelocity.x, playerRB.linearVelocity.y * 0.1f);
        }
    }
    void FlipDirection()
    {
        if (xVelocity < 0)
        {
            transform.localScale = new Vector3(-1, 1, 1);
        }
        else if (xVelocity > 0)
        {
            transform.localScale = new Vector3(1, 1, 1);
        }
    }
    RaycastHit2D Raycast(Vector2 offset, Vector2 rayDirection, float length, LayerMask layer)
    {
        Vector2 pos = transform.position;
        RaycastHit2D hit = Physics2D.Raycast(pos + offset, rayDirection, length, layer);

        Color color = hit ? Color.red : Color.green;
        Debug.DrawRay(pos + offset, rayDirection * length, color);

        return hit;
    }
}

