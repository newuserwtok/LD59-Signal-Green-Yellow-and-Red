using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class SignalManager : MonoBehaviour
{
    public enum SignalState
    {
        Green,
        Yellow,
        Red,
        Blue
    }

    public SignalState currentState;

    public float greenTime = 4f;
    public float yellowTime = 1f;
    public float redTime = 2f;

    private float timer;

    //蓝灯暂停
    public float blueTime = 6f;
    bool isBlue = false;
    SignalState savedState;
    float savedTimer;

    void Start()
    {
        SwitchState(SignalState.Green);
    }

    void Update()
    {
        if (isBlue) return;
        timer -= Time.deltaTime;

        if (timer <= 0)
        {
            NextState();
        }
    }

    void NextState()
    {
        if (currentState == SignalState.Green)
            SwitchState(SignalState.Yellow);
        else if (currentState == SignalState.Yellow)
            SwitchState(SignalState.Red);
        else
            SwitchState(SignalState.Green);
    }

    void SwitchState(SignalState newState)
    {
        currentState = newState;

        switch (newState)
        {
            case SignalState.Green:
                timer = greenTime;
                break;
            case SignalState.Yellow:
                timer = yellowTime;
                break;
            case SignalState.Red:
                timer = Random.Range(redTime - 1f, redTime + 2f);
                break;
        }

        OnSignalChanged?.Invoke(newState);
    }

    public static event System.Action<SignalState> OnSignalChanged;

    public void TurnBlue()
    {
        savedState = currentState;
        savedTimer = timer;

        isBlue = true;
        SwitchState(SignalState.Blue);

        StartCoroutine(BlueStop());
    }
    IEnumerator BlueStop()
    {
        float t = blueTime;

        while (t > 0)
        {
            OnBlueTimerUpdate?.Invoke(t); // UI倒计时
            t -= Time.deltaTime;
            yield return null;
        }

        // 恢复之前状态
        isBlue = false;
        SwitchState(savedState);
        timer = savedTimer;
    }
    public static event System.Action<float> OnBlueTimerUpdate;
}
