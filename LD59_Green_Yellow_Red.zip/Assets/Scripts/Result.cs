using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Result : MonoBehaviour
{
    public TextMeshProUGUI resultTimeText;

    void Start()
    {
        float total = DataManager.instance.totalPlayTime;

        int min = Mathf.FloorToInt(total / 60);
        int sec = Mathf.FloorToInt(total % 60);
        int ms = Mathf.FloorToInt((total * 100) % 100);

        resultTimeText.text = $"{min:00}:{sec:00}:{ms:00}";
    }
    public void QuitGame()
    {
        Application.Quit();
    }
    public void BackToMenu()
    {
        
        DataManager.instance.ResetTime();
        SceneManager.LoadScene("OpenScene");
    }
}