using UnityEngine;
using static SignalManager;

public class PlayerHealth : MonoBehaviour
{
    private Rigidbody2D playerRB;
    private SignalState currentSignal;

    [Header("警戒速度")]
    public float limitedSpeed = 0.1f;

    private void Start()
    {
        playerRB = GetComponent<Rigidbody2D>();
    }
    private void OnEnable()
    {
        SignalManager.OnSignalChanged += OnSignalChanged;
    }

    private void OnDisable()
    {
        SignalManager.OnSignalChanged -= OnSignalChanged;
    }
    private void Update()
    {
        //信号状态检测
        if (currentSignal == SignalState.Red)
        {
            if (Mathf.Abs(playerRB.linearVelocityX) >= limitedSpeed)
            {
                PlayerHurt();
            }
            return;
        }
    }
    void OnSignalChanged(SignalState state)
    {
        currentSignal = state;
    }
    public void PlayerHurt()
    {
        UIManager.UpdateHp();
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Door"))
        {
            collision.gameObject.transform.GetComponent<Door>().ChangeScene();
        }
    }
}
