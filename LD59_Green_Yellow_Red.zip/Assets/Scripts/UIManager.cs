using System;
using System.Collections;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using static SignalManager;

public class UIManager : MonoBehaviour
{
    static UIManager instance;
    public float maxGameTime = 420f;
    private float currentCountDown = 0f;

    private SignalState currentState;
    public TextMeshProUGUI blueTimeText, timeText;
    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
            Destroy(gameObject);
    }
    private void Start()
    {
        currentCountDown = maxGameTime;
    }

    private void Update()
    {
        if(currentState != SignalManager.SignalState.Blue && currentCountDown > 0)
        {
            currentCountDown -= Time.deltaTime;
            UpdateTimeUI(currentCountDown);
        }
        else if(currentState == SignalManager.SignalState.Blue && currentCountDown > 0)
        {
            return;
        }
        else
        {
            ReloadGameScene();
        }
    }
    void ReloadGameScene()
    {
        float usedTime = maxGameTime - currentCountDown;
        DataManager.instance.AddTime(usedTime);

        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    void OnEnable()
    {
        SignalManager.OnBlueTimerUpdate += UpdateBlueTimer;
        SignalManager.OnSignalChanged += OnSignalChanged;
    }

    void OnDisable()
    {
        SignalManager.OnBlueTimerUpdate -= UpdateBlueTimer;
        SignalManager.OnSignalChanged -= OnSignalChanged;
    }

    void UpdateBlueTimer(float time)
    {
        int seconds = (int)time % 60;
        blueTimeText.text = seconds.ToString();
        blueTimeText.enabled = true;
    }
    void OnSignalChanged(SignalManager.SignalState state)
    {
        currentState = state;
        if (state != SignalManager.SignalState.Blue)
        {
            blueTimeText.enabled = false;
        }
        else
        {

        }
    }
    public static void UpdateTimeUI(float time)
    {
        int minutes = (int)time / 60;
        float seconds = (int)time % 60;
        instance.timeText.text = minutes.ToString("00") + " : " + seconds.ToString("00");
    }
    
    public static void UpdateHp()
    {
        instance.currentCountDown -= 0.1f;
    }

    public void WinScene()
    {
        float usedTime = maxGameTime - currentCountDown;
        DataManager.instance.AddTime(usedTime);
    }
}